# AGENTS.md — Personal Project Control Centre

## 1. Mission and authority

You are implementing a personal, local-first project and milestone management mobile application. The supplied reference screenshots are the visual authority. Preserve their visual language and three-screen information architecture; do not redesign the product into a generic productivity dashboard.

Before changing code:
1. Read this file, `PROJECT.md`, `DATABASE.md`, and `design.json` completely.
2. Inspect the existing repository, package scripts, installed dependencies, and platform configuration.
3. Summarize the architecture, constraints, and implementation plan.
4. Identify conflicts or missing decisions. Do not silently invent product requirements.
5. Do not modify application code until the user/maintainer has approved the plan when this is an existing project.

`AGENTS.md` is the mandatory operating contract. `PROJECT.md` defines product behaviour. `DATABASE.md` defines persistence and data integrity. `design.json` defines design tokens and reusable UI rules. If documents conflict, stop and report the conflict rather than guessing.

## 2. Non-negotiable product principles

- Local-first: core application functions must work offline.
- SQLite is the local source of truth.
- No mandatory account, server, cloud database, or internet connection.
- The app is for one person's project control, milestone scheduling, payment bookkeeping, and evidence retention.
- Keep exactly three primary in-app screens: Home, Project Details, and Item Details.
- Splash and app-lock/authentication are entry experiences, not additional primary navigation destinations.
- Do not add team collaboration, chat, CRM, kanban boards, complex Gantt charts, invoicing, online checkout, or unrelated analytics.
- Payment status and completion status are independent.
- Support multiple partial payments per item and multiple evidence attachments per payment.
- Preserve financial history. Never silently delete payment records or evidence.
- Use KES as the initial/default currency, while storing currency codes explicitly.

## 3. Visual design contract

The two supplied reference screenshots are the visual source of truth:
- Deep/vibrant purple visual identity and purple feature surfaces.
- White, generously rounded mobile content surfaces.
- Coral/salmon primary action buttons and active states.
- Soft neutral page backgrounds, restrained gray secondary text, black/dark primary text.
- Minimalist typography, generous whitespace, compact date strip, rounded cards, subtle shadows.
- Bottom navigation treatment should echo the reference, but must not create extra primary destinations beyond the agreed three-screen architecture.
- Home's featured upcoming item/event card is the dominant visual element.
- Project details should feel like the reference event list: clear compact rows, dates/status, amount and easy access to details.
- Item details should use a strong, prominent coral completion action inspired by the reference's “BUY TICKETS” CTA.

Do not substitute a generic Material UI, admin dashboard, dense table-first interface, or unrelated design language. Do not add gradients, illustrations, charts, decorative elements, or new brand colours unless they support the supplied references and are approved.

## 4. Reusable UI and form system

Build reusable primitives and compose all create/edit flows from them. Do not independently style each form.

Required shared form building blocks:
- `AppForm` / form layout and submission state
- `FormSection`
- `FormField` with label, helper text, required marker and error state
- `TextInput`
- `MultilineInput`
- `DateTimeField` / date picker
- `MoneyInput` with currency code
- `SelectField` / status selector
- `AttachmentPicker`
- `EvidencePreview`
- `FormActions` (consistent cancel/save actions)
- Shared validation and error presentation

Create reusable domain forms:
- `ProjectForm` for both create and edit.
- `ProjectItemForm` for both create and edit.
- `PaymentForm` for adding/editing a payment record.
- `ReminderForm` for reminder configuration where needed.

Forms may have different fields, but must share the same components, spacing, label hierarchy, validation behaviour, keyboard handling, save/cancel placement, and loading/error states. Do not create one giant universal form with unrelated fields. Reuse domain forms for create and edit by passing initial values and submit handlers.

## 5. Technical architecture

Target Android first while keeping React Native/Expo architecture portable to iOS unless a requirement makes that impractical.

Preferred stack:
- React Native + Expo
- TypeScript with strict settings
- SQLite for local structured data
- Drizzle ORM and versioned migrations, if compatible with the chosen Expo SDK
- Expo FileSystem (or supported current equivalent) for local attachments
- Expo SecureStore for secrets/PIN verifier material
- Expo Local Authentication for device biometrics
- Expo Notifications for local notifications

Before installing or upgrading packages, verify compatibility with the repository's Expo SDK and current package versions. Do not blindly use deprecated APIs. Prefer Expo-supported APIs and document any deviation.

Use a layered architecture:
- UI/presentation
- application/use-case services
- domain types and business rules
- repositories/data access
- SQLite and filesystem adapters
- notification adapter
- future backup adapter boundary

UI components must not contain raw SQL or duplicate financial calculations. Use repository/service boundaries.

## 6. Data integrity and financial rules

- Store monetary values as integer minor units (for KES, integer shillings may be adequate if fractional amounts are explicitly disallowed; otherwise use minor units consistently). Never use floating-point arithmetic for money.
- Store ISO currency code on relevant financial records.
- Calculate amount paid from successful/recorded payment entries; calculate balance as `max(0, expected amount - amount paid)` for display, while preserving overpayment information rather than discarding it.
- Support partial payments and multiple payments.
- A payment record must have amount, currency, payment date, and payment method/source; M-Pesa transaction reference and raw confirmation text are optional fields.
- Evidence attachments are linked to a payment record, not just loosely to the project.
- Payment status is derived from amounts and payment records (unpaid, partially paid, paid, or overpaid); do not conflate it with item completion.
- Completion is a separate lifecycle state and must be confirmed by default. Record completion timestamp and activity log.
- Editing/deleting a payment must create an auditable activity record. Prefer void/reversal semantics over destructive deletion.
- Use database transactions for operations that update related rows.
- Use foreign keys, indexes, constraints, and migrations.
- Avoid storing derived totals redundantly unless there is a documented cache strategy and reconciliation test.

## 7. Local files and evidence

- Store attachment bytes in app-private local storage, not as large blobs in SQLite.
- Store relative file paths and metadata in SQLite.
- Copy imported files into managed app storage; do not rely on temporary picker URIs.
- Preserve original filename, MIME type, byte size, creation/import timestamp, and checksum where practical.
- Handle missing files gracefully and expose a recoverable state.
- Never claim a file is safely stored until the copy has completed and metadata has been committed.
- Backups must include both database and attachment files, with a manifest and integrity checks.

## 8. Security and privacy

- Provide app PIN lock and optional device biometric unlock.
- Use platform secure storage for PIN verification material and secrets. Never store a plaintext PIN.
- Use a suitable password/PIN hashing or key-derivation approach with salt and platform-supported cryptographic primitives; document threat model and limitations.
- Do not invent a custom biometric implementation; delegate to OS APIs.
- Support lock-on-background and configurable inactivity timeout.
- Keep user records and evidence inside app-private storage.
- Do not log raw M-Pesa messages, transaction references, attachment contents, PINs, or secrets.
- Do not request unnecessary permissions.
- Do not upload or transmit data in Phase 1.

## 9. Notifications

- Use local notifications only in the initial release.
- Schedule reminders for due dates and user-configured advance reminders.
- Support deadline reminders and payment reminders.
- Handle timezone changes, permission denial, rescheduling, deleted/archived items, and app reinstall limitations.
- Persist reminder definitions in SQLite; operating-system scheduled notifications are a derived mechanism and must be reconciled on app startup and after edits.
- Do not promise delivery when OS permissions or battery policies prevent it.

## 10. Google Drive future boundary

Google Drive backup/sync is not part of the initial release. Build a clean backup/export boundary so it can be added later.

Initial backup should be local export/import with:
- database,
- attachment directory,
- manifest/version,
- checksums,
- schema/app version,
- validation before restore.

Do not implement two-way sync, conflict resolution, Drive authentication, or cloud uploads without explicit approval. A future Drive implementation should begin with backup/restore, not multi-device live sync.

## 11. Quality requirements

- TypeScript strict mode; avoid `any`.
- Reusable, accessible components with clear names.
- Responsive layouts for supported phone sizes.
- Keyboard-safe forms and scroll handling.
- Empty, loading, error, permission-denied and success states.
- No dead buttons or fake interactions.
- Unit tests for financial calculations, status derivation, date/reminder logic and validation.
- Repository/database tests for migrations, relationships, cascades/restrict rules and transaction behaviour.
- UI tests for the three primary screens and critical create/payment/complete flows.
- Test offline operation.
- Test backup/restore and evidence integrity before declaring backup complete.
- Run formatting, lint, typecheck, tests and platform build checks before completion.

## 12. Delivery discipline

Implement in small phases. At each phase:
1. State files changed and decisions made.
2. Run relevant tests and report exact outcomes.
3. Do not claim tests passed unless they were run.
4. Update documentation and migrations.
5. Keep scope limited to `PROJECT.md`.
6. Stop and ask when requirements conflict or a security/data-loss decision is unresolved.

Never fabricate sample project records as real user data. Demo data, if added, must be clearly marked and removable.
